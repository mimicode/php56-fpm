<?php

namespace foo;

function strlen($str) {
    return 4;
}
